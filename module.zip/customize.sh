#!/system/bin/sh
SKIPUNZIP=0

# ── Architecture Check ──
if [ "$ARCH" != "arm64" ]; then
    ui_print " "
    ui_print "! [ERROR] Unsupported CPU architecture: $ARCH"
    ui_print "! Only arm64-v8a devices are supported."
    abort
fi

# ── Device & Environment Telemetry ──
DEVICE_MODEL=$(getprop ro.product.model)
ANDROID_VER=$(getprop ro.build.version.release)
API_LEVEL=$(getprop ro.build.version.sdk)

if [ "$KSU" = "true" ]; then
    ROOT_ENV="KernelSU (v$KSU_VER)"
elif [ "$APATCH" = "true" ]; then
    ROOT_ENV="APatch"
elif [ -n "$MAGISK_VER" ]; then
    ROOT_ENV="Magisk ($MAGISK_VER)"
else
    ROOT_ENV="Root Environment"
fi

# ── Stylized Installation Banner ──
ui_print " "
ui_print "╔══════════════════════════════════════════════════╗"
ui_print "║        ⚡ ZEROLAG KERNEL - GYRO ENGINE ⚡        ║"
ui_print "║             Version: v4.6.0-PRO                  ║"
ui_print "║             Author : CODER x JAAT                ║"
ui_print "║             Channel: @zerolagkernel              ║"
ui_print "╚══════════════════════════════════════════════════╝"
ui_print " "
ui_print "- Device    : $DEVICE_MODEL"
ui_print "- Android   : $ANDROID_VER (API $API_LEVEL)"
ui_print "- Manager   : $ROOT_ENV"
ui_print "- Platform  : arm64-v8a [OK]"
ui_print " "

# ── Set Permissions ──
ui_print "- Setting up permissions..."
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/zygisk/arm64-v8a.so" 0 0 0755

# ── Config Generation / Preservation ──
CONFIG_DIR="/data/adb/modules/ZeroLag_Gyro"
CONFIG_FILE="$CONFIG_DIR/config.ini"

mkdir -p "$CONFIG_DIR"
if [ ! -f "$CONFIG_FILE" ]; then
    ui_print "- Initializing default config.ini..."
    cat > "$CONFIG_FILE" << 'EOF'
# ZeroLag OpenGyro v4.6 - Configuration
# ──────────────────────────────────────────────
# Dispatch offset in libsensorservice.so (hex, no 0x prefix)
dispatch_offset=3825C

# Gyroscope sensor handle (Android Type 4 = Gyro)
gyro_handle=4

# Server mode: Unix Abstract Socket @zerolag_gyro + Fallback Port 18472
server_port=18472

# Debug logs (0=off, 1=on) - keep 0 for zero latency
verbose_log=0
dump_raw=0
EOF
    ui_print "- Config written to: $CONFIG_FILE"
else
    ui_print "- Existing config.ini preserved [OK]"
fi

ui_print " "
ui_print "✓ Installation Successful!"
ui_print "⚠️  A device REBOOT is required to activate the sensor hook."
ui_print "════════════════════════════════════════════════════"
ui_print " "
